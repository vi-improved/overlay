#!/bin/sh -x
exec autoreconf -fi
